# YT-Capstone-Project
This is an end to end mlops capstone project for educational purpose.
